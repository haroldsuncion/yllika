<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Bienvenidos a Casa YlliKa</title>
</head>
<body>
<div>
<form method="post" action="scripts/reservas2.php">
name:<input type="text" name="name"><BR>
lastname:<input type="text" name="lastname"><BR>
email:<input type="text" name="email"><BR>
house:
<select name="house"><option>1</option><option>2</option><option>3</option><option>4</option></select><BR>
room:
<select name="room"><option>1</option><option>2</option><option>3</option><option>4</option></select><BR>
fecha de inicio:<input type="date" name="start_date"><BR>
fecha de fin:<input type="date" name="end_date"><BR>
<input type="submit" value="send">
</form>
</div>
</body>
</html>
