create database yllika;
use yllika;
create table reservas(id NOT NULL AUTO_INCREMENT, name NOT NULL VARCHAR(20), lastname NOT NULL VARCHAR(20), habitacion NOT NULL INT(1), casa NOT NULL INT(1));

CREATE TABLE reservas (
        id MEDIUMINT NOT NULL AUTO_INCREMENT,
        name VARCHAR(30) NOT NULL,lastname VARCHAR(30) NOT NULL,
	house INT(1) NOT NULL,habitacion INT(2) NOT NULL,email varchar(30) NOT NULL,
	start_date date not null, end_date date not null,
        PRIMARY KEY (id)
             );
