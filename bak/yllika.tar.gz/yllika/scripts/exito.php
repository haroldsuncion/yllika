<html> 
<head> 
<title></title> 
</head> 
<body>  
<script language="javascript" type="text/javascript">
alert("Sus datos se ingresaron correctamente")
window.location="http://localhost/yllika/index.html";
</script>
</body> 
</html>
