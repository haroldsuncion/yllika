<?php
$host="localhost";
$user="root";
$passwd="wq:mak";
$DB="yllika";

$conexion = mysql_connect($host,$user,$passwd);
mysql_select_db($DB,$conexion);
?>
