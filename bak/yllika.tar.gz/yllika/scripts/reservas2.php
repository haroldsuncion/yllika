<html> 
<head> 
<title></title> 
</head> 
<body> 
<?php
$name = $_POST["name"];
$lastname = $_POST["lastname"];
$house = $_POST["house"];
$room = $_POST["room"];
$email = $_POST["email"];
$start_date = $_POST["start_date"];
$end_date = $_POST["end_date"];

$host="localhost";
$user="root";
$passwd="wq:mak";

$conexion = mysql_connect($host,$user,$passwd);
$DB="yllika";
$database=mysql_select_db($DB,$conexion);
if (!$database){die('ERROR CONEXION CON BD: '.mysql_error());}
$query = "INSERT INTO reservas (name, lastname,email,house,habitacion,start_date,end_date) VALUES ('$name','$lastname','$email',$house,$room,'$start_date','$end_date')";
$result=mysql_query($query);
if(!$result){
echo "La consulta SQL contiene errores.".mysql_error();
exit();
}
else{
$remitente =$email;
$destino = "harold.suncion@gmail.com";
$asunto = "Reserva de habitacion" ;
$mensaje = $name." ".$lastname." desea reservar una habitación. desde:".$start_date." hasta:".$end_date;
$encabezados = "From: $remitente\nReply-To: $remitente\nContent-Type: text/html; charset=iso-8859-1" ;
mail($destino, $asunto, $mensaje, $encabezados) or die ("No se ha podido enviar tu mensaje. Ha ocurrido un error") ;
echo "<p>Se ha enviado un mensaje al administrador con tu solicitud:</p>" ;
echo "<strong><b>$mensaje</b></strong>" ;
header('Location:exito.php');
}
?> 
</body> 
</html>
