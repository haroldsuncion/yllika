<html> 
<head> 
<title></title> 
</head> 
<body> 
<?php
$room=$_POST["room"];
$host="localhost";
$user="root";
$passwd="wq:mak";
$conexion = mysql_connect($host,$user,$passwd);
$DB="yllika";
$database=mysql_select_db($DB,$conexion);
if (!$database){die('ERROR CONEXION CON BD: '.mysql_error());}
$query = "SELECT name, lastname, habitacion FROM reservas WHERE habitacion='$room'";
$result=mysql_query($query);
if (! $result){
   echo "La consulta SQL contiene errores.".mysql_error();
   exit();}
else{
while($row=mysql_fetch_array($result)){
print("<table border='1'>");
print("<tr><td>Nombre</td><td>Apellido</td><td>Habitacion</td></tr><tr>");
print("<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td>");
}
print("</tr></table><br>");
}
?> 
<script language="javascript" type="text/javascript">
</script>
</body> 
</html>
